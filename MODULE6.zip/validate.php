<?php
// Function to validate email using regular expression
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Validate form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = $_POST["firstName"];
    $middleName = $_POST["middleName"];
    $surname = $_POST["surname"];
    $email = $_POST["email"];
    $sex = $_POST["sex"];
    $subjects = isset($_POST["subjects"]) ? $_POST["subjects"] : [];

    // Validate email using regular expression
    if (!validateEmail($email)) {
        die("Invalid email address");
    }

    // Create CSV file if it doesn't exist
    $filename = "infos.csv";
    if (!file_exists($filename)) {
        $header = "First Name,Middle Name,Surname,Email,Sex,Subjects Taken\n";
        file_put_contents($filename, $header);
    }

    // Append data to CSV file
    $data = "$firstName,$middleName,$surname,$email,$sex," . implode(",", $subjects) . "\n";
    file_put_contents($filename, $data, FILE_APPEND);

    // Display the collected data in an HTML table
    echo "<h2>Form Data Received:</h2>";
    echo "<table border='1'>";
    
    $formData = [
        'First Name' => $firstName,
        'Middle Name' => $middleName,
        'Surname' => $surname,
        'Email' => $email,
        'Sex' => $sex,
        'Subjects Taken' => implode(", ", $subjects)
    ];

    foreach ($formData as $key => $value) {
        echo "<tr>";
        echo "<td>{$key}</td><td>{$value}</td>";
        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "<p>No data received.</p>";
}
?>
